# IMG Sysco / FreshPoint Order Sheet

A simple, mobile-friendly ordering checklist based on the uploaded IMG Sysco / FreshPoint Order Cheat Sheet.

## Use it
- Open `index.html` in a browser.
- Enter quantities beside the items you need.
- Quantities save automatically in that browser on that device.
- Search items, print the sheet, export the entered quantities to CSV, or clear quantities.

## Publish it with GitHub Pages
1. Sign in to GitHub and create a new **public** repository (for example, `img-order-sheet`).
2. Upload `index.html` and this `README.md` to the repository's root.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish. The site URL will appear on that Pages screen.
7. Open that URL on your phone and use your browser's **Add to Home Screen** option.

## Important note about saving
This version stores quantities in the browser's local storage. That means entries stay on the same phone/browser, but they do not automatically sync between your phone and computer. Export the order as a CSV if you need to transfer or keep a separate copy.
